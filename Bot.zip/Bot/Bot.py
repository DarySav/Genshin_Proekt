﻿import telebot
from telebot import types

bot = telebot.TeleBot('5433967652:AAF39kCOlcQLzTsiQQt8CQpDKfJGJlk9G7I')


@bot.message_handler(commands=['start'])
def start(message):
    bot.send_message(message.from_user.id, "Привет! Нажми на /help")


@bot.message_handler(commands=['help'])
def help(message):
    markup = types.ReplyKeyboardMarkup(resize_keyboard=True, row_width=2)  # создание новых кнопок
    btn1 = types.KeyboardButton('Персонажи')
    btn2 = types.KeyboardButton('Оружие')
    btn3 = types.KeyboardButton('Артефакты')

    markup.add(btn1, btn2, btn3)
    bot.send_message(message.from_user.id, 'Выберите действие', reply_markup=markup)  # ответ бота


@bot.message_handler(content_types=['text'])
def get_text_messages(message):
    if message.text == 'Персонажи':
        characters_element = 'По стихии\nhttps://docs.google.com/document/d/1M-5pHY2h4G_vVIuhNrSwt06vDJuYVgWYXazeNUfSCqk/edit\n'
        characters_region = 'По региону\nhttps://docs.google.com/document/d/1qbTJ2RCqNzZGOYvZrDR46VqL3beEhkjGXc1tdZpRI1Q/edit\n'
        characters_weapon = 'По оружию\nhttps://docs.google.com/document/d/1ijLifoFxQDLJqeDDYsO-HEeY85qtMVzAIoRGtt6POHw/edit\n'
        total_char = characters_element + characters_region + characters_weapon
        bot.send_message(message.from_user.id, total_char)
    elif message.text == 'Оружие':
        weapon_event = 'Ивент/Стандрат\nhttps://docs.google.com/document/d/1xz8q_NjWswvsGbCQwPWxLVLKBpHGI9m5kyX-uHnlD7U/edit\n'
        weapon_store = 'Магазин\nhttps://docs.google.com/document/d/1P8MLBzBO-X7oEYg52MAMJRxxx7jVs0_D3biSheC6QCE/edit\n'
        total_weap = weapon_event + weapon_store
        bot.send_message(message.from_user.id, total_weap)

    elif message.text == 'Артефакты':
        artifact = 'Артефакт\nhttps://docs.google.com/document/d/1LdILrpBYufU5xfFx0tWtsfdv8_sWpCWr-YQpYwcL0BI/edit'
        bot.send_message(message.from_user.id, artifact)


bot.polling(none_stop=True, interval=0)  # обязательная для работы бота часть